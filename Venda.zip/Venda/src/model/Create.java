package model;

import templateMethod.venda.VendaOnline;

import java.util.List;

public class Create {

    public static Venda createVenda(){
        Cliente cliente = new Cliente("Bruna");
        List<Produto> produtos = List.of(
                new Produto("Sabão", 3, 5 ),
                new Produto("Detergente",2, 5),
                new Produto("Agua", 5,5)
        );
        List<ItemVenda> itemVendas = List.of(
                new ItemVenda(produtos.get(0), 2),
                new ItemVenda(produtos.get(1), 1),
                new ItemVenda(produtos.get(2), 3));

        Venda venda = new Venda(cliente, itemVendas);
        return venda;
    }

}
