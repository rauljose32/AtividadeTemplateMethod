package model;

import java.util.List;
import java.util.function.Function;

public class Venda {

    private Cliente cliente;
    private List<ItemVenda> itemVendas;
    private boolean situacaoVenda = false;

    public Venda(Cliente cliente, List<ItemVenda> itemVendas) {
        this.cliente = cliente;
        this.itemVendas = itemVendas;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<ItemVenda> getItemVendas() {
        return itemVendas;
    }

    public void setItemVendas(List<ItemVenda> itemVendas) {
        this.itemVendas = itemVendas;
    }

    public boolean isSituacaoVenda() {
        return situacaoVenda;
    }

    public void setSituacaoVenda(boolean situacaoVenda) {
        this.situacaoVenda = situacaoVenda;
    }



    public float valorTotal() {
        float valorTotal = 0;
        for (ItemVenda v : itemVendas) {
            valorTotal += v.precoUnitario();
        }
        return valorTotal;
    }

    public void reservar() {
        for (ItemVenda v : itemVendas) {
            System.out.println(v.getProduto().reservarProduto(v.getQuantidade()));
        }
    }

    public void emitirNotaFiscal() {
        System.out.println("NOTA FISCAL");
        System.out.println("Cliente: " + cliente.getNome());
        System.out.println("Itens comprados: ");
        for (ItemVenda v :itemVendas) {
            System.out.println(
                    v.getProduto().getNomeProduto() +
                    " - R$:" + v.getProduto().getPreco() + " - " +
                    v.getQuantidade()+"X - R$:" + v.precoUnitario());
        }
        System.out.println("Valor Total: "+valorTotal());
    }

}
