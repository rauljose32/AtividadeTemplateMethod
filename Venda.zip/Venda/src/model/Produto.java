package model;

public class Produto {

    private String nomeProduto;
    private float preco;
    private int quantidade;

    public Produto(String nomeProduto, float preco, int quantidade) {
        this.nomeProduto = nomeProduto;
        this.preco = preco;
        this.quantidade = quantidade;
    }
    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    public String reservarProduto(int quantidadeReservar) {
        this.quantidade -= quantidadeReservar;
        if (quantidade != 0) {

            return "Produto " + nomeProduto + " reservado: "+quantidadeReservar+", Total em estoque:" + quantidade;

        } else {

            return "Produto " + nomeProduto + " não pode ser reservado"+quantidadeReservar+", total em estoque: " + quantidade;

        }

    }

    @Override
    public String toString() {
        return "Produto{" +
                "nomeProduto='" + nomeProduto + '\'' +
                ", preco=" + preco + '}';
    }
}
