import model.*;
import templateMethod.pagamentoOnline.PagamentoBoleto;
import templateMethod.venda.VendaOnline;

public class Main {
    public static void main(String[] args) {

        var venda = new VendaOnline(PagamentoBoleto::pagamentoBoleto);

        venda.processarPagamento(Create.createVenda());

    }
}