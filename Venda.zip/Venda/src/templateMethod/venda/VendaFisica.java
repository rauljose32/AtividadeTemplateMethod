package templateMethod.venda;

import model.Venda;

import java.util.function.Function;

public class VendaFisica {

    private Function<Venda, String> tipoPagamentoFisico;

    public VendaFisica(Function<Venda, String> tipoPagamentoFisico) {
        this.tipoPagamentoFisico = tipoPagamentoFisico;
    }

    public void processarPagamento(Venda venda){
        System.out.println("Pagamento Fisico: ");
        venda.reservar();
        var r = tipoPagamentoFisico.apply(venda);
        System.out.println(r);
        System.out.println("Cupom Fiscal da compra Gerado: ");
        if(venda.getCliente().getEmail() != null){
            venda.emitirNotaFiscal();
            System.out.println("Nota fiscal emitida e enviada para email do cliente");
            encaminharSolicitacao(venda);
        }else {
            encaminharSolicitacao(venda);
            System.out.println("Emissão de Nota para controle interno");
            venda.emitirNotaFiscal();
        }

    }

    private void encaminharSolicitacao(Venda venda) {
        if(venda.isSituacaoVenda()){
            System.out.println("pedido encaminhado para o setor de entrega de produtos.");
        }else {
            System.out.println("Pagamento ainda não realizado");
        }

    }


}
