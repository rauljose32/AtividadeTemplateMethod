package templateMethod.venda;

import model.Venda;

import java.util.function.Function;

public class VendaOnline {

    private Function<Venda, String> tipoPagamentoOnline;

    public VendaOnline(Function<Venda, String> tipoPagamentoOnline) {
        this.tipoPagamentoOnline = tipoPagamentoOnline;
    }

    public void processarPagamento(Venda venda){
        System.out.println("Pagamento Online: ");
        venda.reservar();
        var r = tipoPagamentoOnline.apply(venda);
        System.out.println(r);
        System.out.println("Cupom Fiscal da compra enviado para email: ");
        venda.emitirNotaFiscal();
        encaminharSolicitacao(venda);
    }


    private void encaminharSolicitacao(Venda venda) {
        if(venda.isSituacaoVenda()){
            System.out.println("pedido encaminhado para o setor de separação de produtos.");
        }else {
            System.out.println("Pagamento ainda não realizado");
        }
    }

}
