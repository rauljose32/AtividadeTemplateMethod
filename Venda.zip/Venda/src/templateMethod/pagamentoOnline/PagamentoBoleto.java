package templateMethod.pagamentoOnline;

import model.Venda;

public class PagamentoBoleto {

    public static String pagamentoBoleto(Venda venda){
        venda.setSituacaoVenda(true);
        return "Pagamento via Boleto realizado: ";
    }

}
