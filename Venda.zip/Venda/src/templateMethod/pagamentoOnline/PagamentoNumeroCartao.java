package templateMethod.pagamentoOnline;

import model.Venda;

public class PagamentoNumeroCartao {

    public static String pagamentoNuemroCartao(Venda venda){
        venda.setSituacaoVenda(true);
        return "Pagamento via Numero do cartão realizado: ";

    }

}
