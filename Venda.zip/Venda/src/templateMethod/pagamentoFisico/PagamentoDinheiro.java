package templateMethod.pagamentoFisico;

import model.Venda;

public class PagamentoDinheiro {

    public static String pagamentoFisicoDinheiro(Venda venda){
        venda.setSituacaoVenda(true);
        return "Pagamento via Dinheiro realizado: ";
    }

}
