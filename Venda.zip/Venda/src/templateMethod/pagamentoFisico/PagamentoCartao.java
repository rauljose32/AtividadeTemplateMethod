package templateMethod.pagamentoFisico;

import model.Venda;

public class PagamentoCartao {

    public static String pagamentoFisicoCartao(Venda venda){
        venda.setSituacaoVenda(true);
        return "Pagamento via Cartão realizado: ";
    }

}
