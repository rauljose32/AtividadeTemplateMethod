package templateMethod.pagamentoFisico;

import model.Venda;

public class PagamentoCarne {

    public static String pagamentoFisicoCarne(Venda venda){
        venda.setSituacaoVenda(true);
        return "Pagamento via Carnê realizado: ";
    }

}
